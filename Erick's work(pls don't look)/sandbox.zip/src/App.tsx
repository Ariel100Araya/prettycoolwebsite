import { useState } from "react";
import "./App.css";

const phrase = [
  "No",
  "Are you sure?",
  "Please?",
  "No More Asking, this is demanding, so please?",
  "Ok, I'm sorry :(",
];
const images = [
  "https://gifdb.com/images/high/cute-animated-dog-walking-x7ozqj2ho8clpaf1.webp",
  "https://media.tenor.com/YNqzKzPOLTsAAAAM/emote.gif",
  "https://gifdb.com/images/high/cute-cow-animation-4ynlh9aqttv9umvb.gif",
  "https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExNTU1MGIwem9yMnU0OXh5cGNscTJleTYzYnRua2Vmamk3N2JubTlqNSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/mnfMtUurOldqTgnnpy/giphy.gif",
  "https://i.pinimg.com/originals/f3/78/4d/f3784dc54de78b85eac662dc55ba64aa.gif",
];

function App() {
  const [noCount, setNoCount] = useState(0);
  const [yesPressed, setYesPressed] = useState(false);
  const yesButtonSize = noCount * 20 + 30;

  function getNoButtonText() {
    return phrase[Math.min(noCount, phrase.length - 1)];
  }

  return (
    <div className="valentineContainer">
      {yesPressed ? (
        <>
          <img
            alt="bears kissing"
            src="https://media.tenor.com/gUiu1zyxfzYAAAAi/bear-kiss-bear-kisses.gif"
          />
          <div className="text">Yay!!!!</div>
        </>
      ) : (
        <>
          <img src={images[Math.min(noCount, images.length - 1)]} />
          <div className="Asking">Will you be my Valentine?</div>
          <div className="buttonContainer">
            <button
              className="yesButton"
              onClick={() => {
                setYesPressed(true);
              }}
              style={{ fontSize: yesButtonSize }}
            >
              Yes
            </button>
            <button
              className="noButton"
              onClick={() => {
                setNoCount(noCount + 1);
              }}
              style={{ fontSize: 30 }}
            >
              {getNoButtonText()}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default App;
